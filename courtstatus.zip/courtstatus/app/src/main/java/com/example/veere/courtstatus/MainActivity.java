package com.example.veere.courtstatus;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.support.design.widget.FloatingActionButton;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.List;


public class MainActivity extends AppCompatActivity {
    ListView listView;
    ArrayAdapter<String> adapter;
    int i=0,q,count;
    int arr[] = new int[50];
    Button viewall,del;
    Mydatabase myDb;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        FloatingActionButton fb=(FloatingActionButton)findViewById(R.id.fb);
        final EditText load=(EditText)findViewById(R.id.load);
        Button bload=(Button) findViewById(R.id.bload);
        listView=(ListView)findViewById(R.id.listview);
        final List<String> arrayList=new ArrayList<>();
        adapter=new ArrayAdapter<String>(this,android.R.layout.simple_list_item_1,arrayList);
        listView.setAdapter(adapter);
        myDb=new Mydatabase(this.getApplicationContext());
        Button viewall=(Button)findViewById(R.id.viewall);
        Button del=(Button)findViewById(R.id.del);
        fb.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) { ;
                GregorianCalendar c = new GregorianCalendar();
                int day = c.get(Calendar.DATE);
                int month = c.get(Calendar.MONTH);
                int year= c.get(Calendar.YEAR);
                int min= c.get(Calendar.MINUTE);
                int h= c.get(Calendar.HOUR_OF_DAY);
                i++;
                q=day+month+year+min+h+i;
                arrayList.add(Integer.toString(q));
                adapter.notifyDataSetChanged();
                Toast.makeText(getBaseContext(),"Case Added",Toast.LENGTH_SHORT).show();

            }
        });
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                int x=(int) parent.getItemIdAtPosition(position);
                Toast.makeText(getBaseContext(),adapter.getItem(position)+"IS selectedd",Toast.LENGTH_SHORT).show();
                Intent i=new Intent(getApplicationContext(),detailsActivity.class);
                i.putExtra("v1", q*1);
                i.putExtra("v3",adapter.getItem(position));
                startActivity(i);

            }
        });
        viewall.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Cursor res = myDb.getAllData();
                if(res.getCount() == 0) {
                    // show message
                    showMessage("Error","Nothing found");
                    return;
                }

                StringBuffer buffer = new StringBuffer();
                while (res.moveToNext()) {
                    buffer.append("title :"+ res.getString(0)+"\n");
                    buffer.append("date :"+res.getString(1)+"\n");
                    buffer.append("name :"+ res.getString(2)+"\n");
                    buffer.append("Act :"+ res.getString(3)+"\n");
                    buffer.append("advocate :"+ res.getString(4)+"\n");
                    buffer.append("type :"+ res.getString(5)+"\n");
                    buffer.append("sol :"+ res.getString(6)+"\n\n");
                    }

                // Show all data
                showMessage("Data",buffer.toString());

            }
        });

        del.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
               int deletedRows = myDb.deleteData(load.getText().toString());
                if (deletedRows > 0)
                    Toast.makeText(MainActivity.this, "Data Deleted", Toast.LENGTH_LONG).show();
                else
                    Toast.makeText(MainActivity.this, "Data not Deleted", Toast.LENGTH_LONG).show();
            }
        });

    }
    public void showMessage(String title, String Message) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setCancelable(true);
        builder.setTitle(title);
        builder.setMessage(Message);
        builder.show();
    }


}


