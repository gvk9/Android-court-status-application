package com.example.veere.courtstatus;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.text.DateFormat;
import java.util.Date;

public class detailsActivity extends AppCompatActivity {
    TextView title,date;
    EditText advocate,Act,name,type,sol;
    Button create,update;
    int q,id,item;
    int arr[] = new int[50];
    String ct,cA,ca,cs,cn,cd;
    Mydatabase myDb;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_details);
        Button create=(Button) findViewById(R.id.create);
        final Button update=(Button) findViewById(R.id.update);
        title=(TextView) findViewById(R.id.title);
        date=(TextView) findViewById(R.id.date);
        name=(EditText) findViewById(R.id.name);
        Act=(EditText) findViewById(R.id.Actx);
        type=(EditText) findViewById(R.id.typex);
        sol=(EditText) findViewById(R.id.solx);
        advocate=(EditText) findViewById(R.id.advocate);
        myDb=new Mydatabase(this.getApplicationContext());
        String currentDateTimeString = DateFormat.getDateTimeInstance().format(new Date());
        date.setText(currentDateTimeString);
        cd=currentDateTimeString;
        q=getIntent().getExtras().getInt("v1");
        title.setText(Integer.toString(q));
        create.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
              ct=type.getText().toString();
              cA=Act.getText().toString();
              ca=advocate.getText().toString();
              cs=sol.getText().toString();
              cn=name.getText().toString();
              myDb.doInsert(Integer.toString(q),cd.toString(),cn,cA,ca,ct,cs);

            }

        });

        update.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                boolean isUpdate = myDb.updateData(title.getText().toString(),sol.getText().toString());
                if (isUpdate == true)
                    Toast.makeText(detailsActivity.this, "Data Update", Toast.LENGTH_LONG).show();
                else
                    Toast.makeText(detailsActivity.this, "Data not Updated", Toast.LENGTH_LONG).show();

            }
        });



    }



}

