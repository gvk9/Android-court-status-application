package com.example.veere.courtstatus;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class Mydatabase extends SQLiteOpenHelper {
    static final private String DB_NAME="Courth";
    static final private String TABLE_NAME="casexn";
    public static final int DB_VER = 1;

    TextView cnid,date,na,Actx,np,typex;
    EditText solx;
    Button update;

    Context ctx;
    SQLiteDatabase myDb;
    public static final String COL_1 = "title";
    public static final String COL_2= "date";
    public static final String COL_3 = "name";
    public static final String COL_4 = "Act";
    public static final String COL_5 = "advocate";
    public static final String COL_6= "type";
    public static final String COL_7= "sol";


    public Mydatabase(Context context)
    {
        super(context,DB_NAME,null,DB_VER);
        ctx = context;
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("create table "+TABLE_NAME+" (title String,date String,name String,Act String,advocate String,type String,sol String);");
        Log.i("Database","Table created");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("drop table if exists " + TABLE_NAME);
        onCreate(db);


    }
    public boolean doInsert (String title,String date,String name,String Act,String advocate,String type,String sol) {
        myDb=getWritableDatabase();
        myDb.execSQL("insert into "+TABLE_NAME+" (title,date,name,Act,advocate,type,sol) values('"+title+"','"+date+"','"+name+"','"+Act+"','"+advocate+"','"+type+"','"+sol+"');");
        Toast.makeText(ctx,"CASE saved Successfully",Toast.LENGTH_LONG).show();
        return true;
    }
    public Cursor getAllData() {
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor res = db.rawQuery("select * from "+TABLE_NAME,null);
        return res;
    }

    public boolean updateData(String title, String sol) {
       myDb=getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(COL_1,title);
        contentValues.put(COL_7,sol);
        myDb.update(TABLE_NAME, contentValues, "title = ?",new String[] {title});
        return true;


    }
    public Integer  deleteData(String id) {
        myDb=getWritableDatabase();
        return myDb.delete(TABLE_NAME, "title= ?",new String[] {id});

    }

}